package zatribune.spring.pps.data.entities;

public enum PicStatus {
    APPROVED, PENDING,DECLINED,DELETED;

    @Override
    public String toString() {
        return super.toString();
    }
}
