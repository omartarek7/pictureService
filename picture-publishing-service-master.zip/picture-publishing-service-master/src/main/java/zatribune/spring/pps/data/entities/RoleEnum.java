package zatribune.spring.pps.data.entities;

public enum  RoleEnum {
    ROLE_USER,ROLE_ADMIN
}
