package zatribune.spring.pps.data.entities;

public enum PicCategory {
    living_thing, machine, nature
}
