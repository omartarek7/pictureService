package zatribune.spring.pps.controllers;

public enum ModalType {
    LOGIN,INFO,DELETE,ERROR
}
