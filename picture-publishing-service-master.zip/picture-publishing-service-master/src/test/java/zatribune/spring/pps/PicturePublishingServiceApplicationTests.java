package zatribune.spring.pps;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PicturePublishingServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
